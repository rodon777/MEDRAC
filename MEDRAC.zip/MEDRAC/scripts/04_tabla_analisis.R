
PF <- function(list1,list2,object){
	
	M1 <-as.matrix(list1[[object]])
	n1 <-seq(1:nrow(M1))
	M1 <-cbind(n1,M1)
	colnames(M1)[1]<-names(list1[object])
	
	M2 <-as.matrix(list2[[object]])
	n2 <-seq(1:nrow(M2))
	M2 <-cbind(n2,M2)
	colnames(M2)[1]<-names(list2[object])
	
	M <- list(M1,M2)
	print(M)
	
}

M40 <- PF(L1,L2,40)

###########################################################
###########################################################
###########################################################


AN <- function(list,object,type_cont_ci,type_cont_ce, activate_area){

	tc_ce <- type_cont_ce
	tc_ci <- type_cont_ci
	
	if(object == 1){
		
		file.names <- dimnames(list[[1]])
	}
	if(object == 2){
		
		file.names <- dimnames(list[[2]])
	}

	print(file.names[[2]][1])
	
	print("Sumario")
	print(summary(list[[object]][,-1]))
	print("Covarianza")
	print(cov(list[[object]][,-1]))
	print("Correlacion")
	print(cor(list[[object]][,-1]))

###########################################################
graphics.off()
dev.new(width=4.15, height=4.15)	
	
plot(list[[2]][,2:3],type = tc_ce, cex = 0.2, lty = 1, lwd = 1, col = "blue", cex.axis=0.8, las=1, main=file.names[[2]][1], cex.main=1, xlab = "width (mm)", ylab = "height (mm)")
lines(list[[1]][,2:3], type = tc_ci, cex = 0.2, col = "red")



###########################################################

if(activate_area == 1){
	
	cord.data <- c(min(list[[object]][,2]),list[[object]][,2],list[[object]][length(list[[object]][,2]),2])
	cord.y <- c(0,list[[object]][,3],0)

	polygon(cord.data,cord.y,col=alpha("grey",0.4),lty = 0.1, lwd = 0.1, pch = 16)

	auc(list[[object]][,2],list[[object]][,3], type = 'spline',from=min(list[[object]][,2],to=list[[object]][length(list[[object]][,2]),2]))

}else{
	
	
}
 
###########################################################
###########################################################
rgl.clear()
rgl.close()
open3d()

par3d(windowRect = c(20, 30, 500, 500), cex = 0.6)

observer3d(0, 0, 500)

shade3d(turn3d(list[[1]][,3],list[[1]][,2]), col = "grey")

shade3d(turn3d(list[[2]][,3],list[[2]][,2]), col = "grey")

 		rgl.bbox(color=c("#333377","black"), emission="#333377",
         	specular="#3333FF", shininess=1, alpha = 0.8)
         
         legend3d("topright", legend = paste('Type', c('A', 'B', 'C')), pch = 16, col = rainbow(3), 				cex=1, inset=c(0.02))

         
###########################################################

ci <- cbind(list[[1]][,3],list[[1]][,2])
ce <- cbind(rev(M40[[2]][,3]),rev(M40[[2]][,2]))

data <- rbind(ci,ce)
		
	data <- return(turn3d(data))
	
	return(data)
	
}

data <- AN(M40,2,"o","o",1)

###########################################################

open3d()
plot3d(data$vb[2,],data$vb[3,],data$vb[1,], xlab="X axis (mm)", ylab = "Y axis (mm)", zlab = "Z axis (mm)")
aspect3d(1, 1, 0.5)

## setwd("/Users/rodrigo_donoso/Desktop/MEDRAC/movies")
## movie3d( spin3d(axis = c(0, 1, 1), rpm = 2), duration = 100, dir = getwd(), type = "gif")
