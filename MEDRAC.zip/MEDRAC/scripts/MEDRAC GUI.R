#####################################
### MEDRAC Graphic User Interface ###
#####################################

require(digest)

require(gWidgets)
options(guiToolkit="tcltk")
require(gWidgetstcltk)

#####################################

win <- gwindow("MEDRAC", visible=TRUE)
size(win) <- c(500,400)



group <- ggroup(horizontal=F, container=win)

	glabel("1.0 Data Dump", container=group, anchor=c(-1,1))

buttons <- ggroup(horizontal=T, container=win)

import <- gbutton("Import Data Base", container=buttons, anchor=c(-1,1), handler=function(h,...) ggenericwidget(IMP, help = gbutton("Import Data Base", container=buttons, anchor=c(-1,1), container=gwindow("Import Data Base", visible=T, width=500, height=200)))

interpolation <- gbutton("Interpolate Arrays", container=buttons, anchor=c(0,1), handler=function(h,...) ggenericwidget(AR, container=gwindow("Interpolate Arrays", visible=T, width=500, height=200)))

normalization <-  gbutton("Normalization", container=buttons, anchor=c(1,1), handler=function(h,...) ggenericwidget(NF, container=gwindow("Normalization", visible=T, width=500, height=200)))

viewtable <-  gbutton("View Table", container=buttons, anchor=c(1,1), handler=function(h,...) ggenericwidget(GT, container=gwindow("View Table", visible=T, width=500, height=200)))



group1 <- ggroup(horizontal=F, container=win)

	glabel("1.1 Modificate Parameters", container=group1, anchor=c(-1,0.5))
	
	buttons1 <- ggroup(horizontal=T, container=win)

origen_ext <- gbutton("Change to External Origin", container=buttons1, anchor=c(-1,1), handler=function(h,...) ggenericwidget(OR_ce, container=gwindow("Change to External Origin", visible=T, width=500, height=200)))

origen_int <- gbutton("Change to Internal Origin", container=buttons1, anchor=c(0,1), handler=function(h,...) ggenericwidget(OR_ci, container=gwindow("Change to Internal Origin", visible=T, width=500, height=200)))

individuos <-  gbutton("Unit List", container=buttons1, anchor=c(1,1), handler=function(h,...) ggenericwidget(IND, container=gwindow("Unit List", visible=T, width=500, height=200)))



group2 <- ggroup(horizontal=F, container=win)

	glabel("1.2 Explorer Analisis", container=group2, anchor=c(-1,0.5))
	
	buttons2 <- ggroup(horizontal=T, container=win)

summary <- gbutton("Summary", container=buttons2, anchor=c(-1,1), handler=function(h,...) ggenericwidget(sumario, container=gwindow("Summary", visible=T, width=500, height=200)))

correlacion <- gbutton("Correlation", container=buttons2, anchor=c(0,1), handler=function(h,...) ggenericwidget(COR, container=gwindow("Correlation", visible=T, width=500, height=200)))

covarianza <-  gbutton("Covariance", container=buttons2, anchor=c(1,1), handler=function(h,...) ggenericwidget(COV, container=gwindow("Covariance", visible=T, width=500, height=200)))

pca <-  gbutton("PCA", container=buttons2, anchor=c(1,1), handler=function(h,...) ggenericwidget(PCA, container=gwindow("PCA", visible=T, width=500, height=200)))




group3 <- ggroup(horizontal=F, container=win)

	glabel("2.0 Graphics", container=group3, anchor=c(-1,0.5))
	
	buttons3 <- ggroup(horizontal=T, container=win)

summary <- gbutton("Graphic 2D and 3D", container=buttons3, anchor=c(-1,1), handler=function(h,...) ggenericwidget(TD, container=gwindow("Graphic 2D and 3D", visible=T, width=500, height=200)))

correlacion <- gbutton("Comparative Graphics", container=buttons3, anchor=c(0,1), handler=function(h,...) ggenericwidget(COMP, container=gwindow("Comparative Graphics", visible=T, width=500, height=200)))

covarianza <-  gbutton("Trellis Graphics", container=buttons3, anchor=c(1,1), handler=function(h,...) ggenericwidget(PO, container=gwindow("Trellis Graphics", visible=T, width=500, height=200)))

